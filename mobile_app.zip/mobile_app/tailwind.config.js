/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx,ts,tsx}", "./components/**/*.{js,jsx,ts,tsx}"],
  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors: {
        primary: '#b70100',
        'primary-container': '#e60000',
        'primary-fixed': '#ffdad4',
        'on-primary': '#ffffff',
        surface: '#fcf8fb',
        'surface-container': '#f0edef',
        'surface-container-low': '#f6f3f5',
        'surface-container-high': '#eae7ea',
        'surface-container-highest': '#e4e2e4',
        'on-surface': '#1b1b1d',
        'on-surface-variant': '#5f3f3a',
        outline: '#946e68',
        'outline-variant': '#e9bcb5',
        secondary: '#5f5e60',
        'secondary-container': '#e2dfe1',
      },
      fontFamily: {
        headline: ['System'],
        body: ['System'],
      }
    },
  },
  plugins: [],
}
