import { Tabs } from 'expo-router';
import React from 'react';
import { View, Text, TouchableOpacity, SafeAreaView } from 'react-native';
import { Package } from 'lucide-react-native';

function CustomHeader() {
  return (
    <SafeAreaView className="bg-white/90 z-50 border-b border-zinc-100">
      <View className="flex-row h-16 items-center justify-between px-4 mt-2">
        <View className="flex-row items-center gap-3">
          {/* No back button needed on the main tab */}
          <Text className="text-lg font-bold tracking-tight text-on-surface">
            Asset Details
          </Text>
        </View>
        <View className="flex-row items-center gap-2">
          <Text className="text-lg font-black tracking-widest text-[#b70100]">VODAFONE</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

function CustomTabBar({ state, descriptors, navigation }: any) {
  return (
    <View className="flex-row items-center justify-around bg-white/90 px-4 pb-6 pt-3 shadow-lg border-t border-zinc-100 absolute bottom-0 w-full z-50">
      {state.routes.map((route: any, index: number) => {
        const { options } = descriptors[route.key];
        const isFocused = state.index === index;
        
        // Only Assets tab left
        if (route.name !== 'index') return null;

        const color = isFocused ? '#b70100' : '#a1a1aa';

        return (
          <TouchableOpacity
            key={route.key}
            accessibilityState={isFocused ? { selected: true } : {}}
            accessibilityLabel={options.tabBarAccessibilityLabel}
            onPress={() => {
              const event = navigation.emit({
                type: 'tabPress',
                target: route.key,
                canPreventDefault: true,
              });
              if (!isFocused && !event.defaultPrevented) {
                navigation.navigate(route.name);
              }
            }}
            className="items-center justify-center gap-1 px-6 py-2"
          >
            <Package size={24} color={color} fill={isFocused ? color : "none"} />
            <Text 
              style={{ color }}
              className="text-[10px] font-semibold uppercase tracking-wider mt-1"
            >
              Assets
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

export default function TabLayout() {
  return (
    <View className="flex-1 bg-surface-container-low">
      <Tabs
        tabBar={(props) => <CustomTabBar {...props} />}
        screenOptions={{
          header: () => <CustomHeader />,
          sceneStyle: { paddingBottom: 80, backgroundColor: '#f6f3f5' }
        }}>
        <Tabs.Screen
          name="index"
          options={{ title: 'Assets' }}
        />
      </Tabs>
    </View>
  );
}
