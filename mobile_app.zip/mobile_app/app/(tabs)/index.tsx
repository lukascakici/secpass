import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, TouchableOpacity, Modal, FlatList, SafeAreaView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Camera, QrCode, Info, Send, Package, ChevronDown } from 'lucide-react-native';
import { useRouter } from 'expo-router';

// Custom Dropdown Component
function CustomDropdown({ 
  label, 
  value, 
  options, 
  onSelect 
}: { 
  label: string, 
  value: string, 
  options: string[], 
  onSelect: (val: string) => void 
}) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <View className="flex-1 w-full relative">
      <TouchableOpacity 
        activeOpacity={0.7}
        onPress={() => setIsOpen(true)}
        className="w-full bg-surface-container-highest px-4 h-14 rounded-xl flex-row items-center justify-between"
      >
        <Text className="text-on-surface font-medium text-sm">{value}</Text>
        <ChevronDown size={20} color="#b70100" />
      </TouchableOpacity>

      <Modal transparent visible={isOpen} animationType="fade">
        <View className="flex-1 justify-end bg-black/50">
          <TouchableOpacity 
            className="absolute inset-0"
            activeOpacity={1}
            onPress={() => setIsOpen(false)} 
          />
          <View className="bg-white rounded-t-3xl max-h-[60%] overflow-hidden pt-2 pb-6 shadow-2xl">
            {/* Handle Bar */}
            <View className="w-12 h-1.5 bg-zinc-300 rounded-full self-center mb-4 mt-2" />
            
            <Text className="text-center font-bold text-lg mb-4 text-zinc-800 px-4">
              Select {label}
            </Text>
            
            <FlatList 
              data={options}
              keyExtractor={(item) => item}
              showsVerticalScrollIndicator={false}
              renderItem={({ item }) => (
                <TouchableOpacity 
                  activeOpacity={0.7}
                  onPress={() => {
                    onSelect(item);
                    setIsOpen(false);
                  }}
                  className={`px-6 py-4 border-b border-zinc-100 flex-row items-center justify-between ${value === item ? 'bg-primary/5' : ''}`}
                >
                  <Text className={`text-base flex-1 ${value === item ? 'font-bold text-primary' : 'font-medium text-zinc-700'}`}>
                    {item}
                  </Text>
                  {value === item && (
                    <View className="w-3 h-3 rounded-full bg-primary" />
                  )}
                </TouchableOpacity>
              )}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const SITES_DATA: Record<string, string[]> = {
  "Site 1": ["Room 1A", "Room 1B", "Room 1C"],
  "Site 2": ["Room 2A", "Room 2B"],
  "Site 3": ["Room 3X", "Room 3Y", "Room 3Z"],
  "Site 4": ["Room 4 Alpha", "Room 4 Beta"],
  "Site 5": ["Main Server Room", "Backup Room"],
};

const SITE_NAMES = Object.keys(SITES_DATA);

export default function AssetDetailsScreen() {
  const router = useRouter();
  
  const [siteName, setSiteName] = useState(SITE_NAMES[0]);
  const [roomName, setRoomName] = useState(SITES_DATA[SITE_NAMES[0]][0]);

  return (
    <ScrollView className="flex-1 bg-surface" contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 24, paddingBottom: 64 }}>
      {/* Hero Header */}
      <View className="mb-6 rounded-2xl shadow-lg border border-primary/10 overflow-hidden">
        <LinearGradient 
          colors={['#b70100', '#e60000']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          className="p-6 h-36"
        >
          <View className="z-10 relative">
            <Text className="text-white/80 font-medium mb-1 uppercase tracking-widest text-[10px]">Inventory Intake</Text>
            <Text className="text-3xl font-extrabold tracking-tight text-white">New Entry</Text>
          </View>
          <View className="absolute -right-4 -bottom-4 opacity-20">
            <Package size={120} color="#fff" />
          </View>
        </LinearGradient>
      </View>

      {/* Form Section */}
      <View className="space-y-4 gap-4">
        
        {/* Site Name (Dropdown) */}
        <View className="space-y-1.5 gap-2">
          <Text className="text-[10px] font-bold text-secondary uppercase tracking-[1px] px-1">Site Name</Text>
          <CustomDropdown 
            label="Site Name"
            value={siteName}
            options={SITE_NAMES}
            onSelect={(val) => {
              setSiteName(val);
              setRoomName(SITES_DATA[val][0]); 
            }}
          />
        </View>

        <View className="flex-row gap-4 w-full">
          {/* Room Name (Dropdown based on Site Name) */}
          <View className="space-y-1.5 gap-2 flex-1">
            <Text className="text-[10px] font-bold text-secondary uppercase tracking-[1px] px-1">Room Name</Text>
            <CustomDropdown 
              label="Room"
              value={roomName}
              options={SITES_DATA[siteName]}
              onSelect={setRoomName}
            />
          </View>

          {/* Rack Name */}
          <View className="space-y-1.5 gap-2 flex-1">
            <Text className="text-[10px] font-bold text-secondary uppercase tracking-[1px] px-1">Rack Name</Text>
            <TextInput 
              placeholder="R-12"
              placeholderTextColor="#5f5e6080"
              className="w-full bg-surface-container-highest px-4 py-3.5 rounded-xl text-on-surface font-medium text-sm h-14"
            />
          </View>
        </View>

        {/* Serial Number */}
        <View className="space-y-1.5 gap-2">
          <Text className="text-[10px] font-bold text-secondary uppercase tracking-[1px] px-1">Serial Number</Text>
          <View className="relative justify-center">
            <TextInput 
              placeholder="SN-XXXX-XXXX"
              placeholderTextColor="#5f5e6080"
              className="w-full bg-surface-container-highest px-4 h-14 rounded-xl text-on-surface font-medium pr-12 text-sm"
            />
            <TouchableOpacity 
              onPress={() => router.push('/scanner')}
              className="absolute right-2 p-2 bg-white rounded-lg shadow-sm active:opacity-70 transition-opacity whitespace-nowrap"
            >
              <Camera size={20} color="#b70100" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Hardware Detail */}
        <View className="space-y-1.5 gap-2">
          <Text className="text-[10px] font-bold text-secondary uppercase tracking-[1px] px-1">Hardware Detail</Text>
          <View className="relative">
            <TextInput 
              placeholder="Describe hardware specifications..." 
              placeholderTextColor="#5f5e6080"
              multiline
              numberOfLines={3}
              textAlignVertical="top"
              className="w-full bg-surface-container-highest px-4 py-3.5 rounded-xl text-on-surface font-medium pr-12 text-sm min-h-[80px]"
            />
            <TouchableOpacity 
              onPress={() => router.push('/scanner')}
              className="absolute right-2 top-2 p-2 bg-white rounded-lg shadow-sm active:opacity-70 transition-opacity"
            >
              <QrCode size={20} color="#b70100" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Hint */}
        <View className="flex-row items-start gap-3 p-4 bg-primary/5 rounded-2xl border border-primary/10 mt-2">
          <View className="mt-0.5">
            <Info size={16} color="#b70100" />
          </View>
          <Text className="flex-1 text-xs text-on-surface/70 leading-5">
            Ensure sufficient lighting when scanning. Records sync in real-time with the central database.
          </Text>
        </View>

        {/* Submit Button */}
        <TouchableOpacity 
          className="w-full mt-4 rounded-full overflow-hidden shadow-lg"
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={['#b70100', '#e60000']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            className="w-full py-4 flex-row items-center justify-center gap-2"
          >
            <Text className="text-white font-bold text-lg">Submit Asset Details</Text>
            <Send size={20} color="#fff" />
          </LinearGradient>
        </TouchableOpacity>
        
      </View>
    </ScrollView>
  );
}
