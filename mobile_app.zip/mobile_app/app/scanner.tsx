import React, { useEffect } from 'react';
import { View, Text, TouchableOpacity, Dimensions } from 'react-native';
import { Image } from 'expo-image';
import { Camera, Image as ImageIcon, History, Zap, ArrowLeft } from 'lucide-react-native';
import Animated, { useSharedValue, useAnimatedStyle, withRepeat, withTiming, Easing } from 'react-native-reanimated';
import { useRouter, Stack } from 'expo-router';

const { width, height } = Dimensions.get('window');
const SCANNER_SIZE = 300;

export default function ScannerScreen() {
  const router = useRouter();
  const scanLineY = useSharedValue(-140);

  useEffect(() => {
    scanLineY.value = withRepeat(
      withTiming(140, { duration: 2000, easing: Easing.linear }),
      -1,
      true
    );
  }, []);

  const scanLineStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: scanLineY.value }],
  }));

  const goBack = () => {
    if (router.canGoBack()) {
      router.back();
    } else {
      router.replace('/');
    }
  };

  return (
    <View className="flex-1 bg-black items-center justify-center overflow-hidden">
      <Stack.Screen options={{ headerShown: false }} />
      
      {/* Background Image */}
      <Image 
        source={{ uri: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?q=80&w=2000&auto=format&fit=crop' }}
        style={{ position: 'absolute', width: '100%', height: '100%', opacity: 0.8 }}
        contentFit="cover"
      />

      {/* Overlay - Top, Bottom, Left, Right panels */}
      <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: height / 2 + SCANNER_SIZE / 2, backgroundColor: 'rgba(0,0,0,0.6)' }} />
      <View style={{ position: 'absolute', top: height / 2 + SCANNER_SIZE / 2, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)' }} />
      <View style={{ position: 'absolute', top: height / 2 - SCANNER_SIZE / 2, left: 0, right: width / 2 + SCANNER_SIZE / 2, bottom: height / 2 - SCANNER_SIZE / 2, backgroundColor: 'rgba(0,0,0,0.6)' }} />
      <View style={{ position: 'absolute', top: height / 2 - SCANNER_SIZE / 2, left: width / 2 + SCANNER_SIZE / 2, right: 0, bottom: height / 2 - SCANNER_SIZE / 2, backgroundColor: 'rgba(0,0,0,0.6)' }} />

      {/* Floating Header */}
      <View className="absolute top-12 left-4 z-50">
        <TouchableOpacity 
          onPress={goBack}
          className="w-12 h-12 bg-white/20 rounded-full items-center justify-center active:opacity-70"
        >
          <ArrowLeft size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Target Reticle */}
      <View style={{ width: SCANNER_SIZE, height: SCANNER_SIZE, position: 'absolute' }}>
        <View className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-primary rounded-tl-3xl" />
        <View className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-primary rounded-tr-3xl" />
        <View className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-primary rounded-bl-3xl" />
        <View className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-primary rounded-br-3xl" />
        
        {/* Animated Scan Line */}
        <Animated.View 
          className="absolute left-4 right-4 h-1 bg-primary rounded-full shadow-lg shadow-primary"
          style={[{ top: SCANNER_SIZE / 2 }, scanLineStyle]}
        />
      </View>

      {/* Hint Text */}
      <View className="absolute top-[65%] px-6 py-3 bg-black/60 rounded-full border border-white/20">
        <Text className="text-white text-sm font-medium tracking-wide">Align QR code or Barcode within frame</Text>
      </View>

      {/* Utility Controls */}
      <View className="absolute bottom-12 w-full flex-row justify-center gap-6 z-30">
        <TouchableOpacity className="w-14 h-14 bg-black/40 border border-white/20 rounded-full items-center justify-center">
          <Zap size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity 
          onPress={goBack}
          className="w-14 h-14 bg-black/40 border border-white/20 rounded-full items-center justify-center p-2"
        >
          <Camera size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity className="w-14 h-14 bg-black/40 border border-white/20 rounded-full items-center justify-center p-2">
          <ImageIcon size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity className="w-14 h-14 bg-black/40 border border-white/20 rounded-full items-center justify-center p-2">
          <History size={24} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
}
